<?php

session_start();

?>

<center>
    <h2>Music Favorit</h2>
    <h1>Welcome Sir <?php echo $_SESSION['nama']; ?></h1>
</center>